//import java.io.DataOutputStream;
//import java.io.*;
//import java.net.*;
//import java.util.*;
//
//public class GuessNumber {
//    public static String guess() {
//        String base = "1111";
//        int firstResp = connectServer(base).charAt(0) - '0';
//        if (firstResp == 4) {
//            return base;
//        }
//
//        char[] res = new char[4];
//        Arrays.fill(res, '0');
//        for (int i = 0; i < 4; i++) {
//            int lastResp = firstResp;
//            char[] charBase = base.toCharArray();
//            for (int j = 2; j < 6; j++) {
//                charBase[i] = (char)('0' + j);
//                int resp = connectServer(new String(charBase)).charAt(0) - '0';
//                if (resp == 4) {
//                    return new String(charBase);
//                }
//                if (resp != lastResp) {
//                    res[i] = lastResp > resp ? '1' : (char)('0' + j);
//                    break;
//                }
//            }
//            if (res[i] == '0') {
//                res[i] = '6';
//            }
//        }
//
//        return new String(res);
//    }
//
//    private static String connectServer(String input) {
//        String serverName = "0.0.0.0";//ip
//        int port = 44;//端
//        String res = "";
//        try {
//
//            Socket client = new Socket(serverName, port);
//            OutputStream outToServer = client.getOutputStream();
//            DataOutputStream out = new DataOutputStream(outToServer);
//
//            out.writeUTF(input);
//            InputStream inFromServer = client.getInputStream();
//            DataInputStream in = new DataInputStream(inFromServer);
//            res = in.readUTF();
//            System.out.println("Server says " + res);
//            client.close();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        return res;
//    }
//
//    public static void main(String[] args) {
//        System.out.println(guess());
//    }
//}
//
//
////package com.company;
////
////        import java.io.DataInputStream;
////        import java.io.DataOutputStream;
////        import java.io.IOException;
////        import java.net.ServerSocket;
////        import java.net.Socket;
////        import java.net.SocketTimeoutException;
////
////public class Main extends Thread {
////    private ServerSocket serverSocket;
////
////    public Main(int port) throws IOException {
////        serverSocket = new ServerSocket(port);
////        serverSocket.setSoTimeout(1000000);
////    }
////
////    public void run() {
////        while (true) {
////            try {
////                System.out.println("Waiting for client on port " +
////                        serverSocket.getLocalPort() + "..." + serverSocket.getLocalSocketAddress());
////                Socket server = serverSocket.accept();
////                System.out.println("Just connected to " + server.getRemoteSocketAddress());
////                DataInputStream in = new DataInputStream(server.getInputStream());
////
////                String back = guessServer(in.readUTF(), target);
////                System.out.println(back);
////
////                DataOutputStream out = new DataOutputStream(server.getOutputStream());
////                out.writeUTF(back);
////                server.close();
////
////            } catch (SocketTimeoutException s) {
////                System.out.println("Socket timed out!");
////                break;
////            } catch (IOException e) {
////                e.printStackTrace();
////                break;
////            }
////        }
////    }
////
////    String target = "6543";
////
////    private String guessServer(String guess, String secret) {
////        int[] smemo = new int[10];
////        int[] gmemo = new int[10];
////        int cow = 0;
////        int bull = 0;
////        for (int i = 0; i < secret.length(); i++) {
////            if (secret.charAt(i) == guess.charAt(i)) bull++;
////            else {
////                smemo[(int) (secret.charAt(i) - '0')]++;
////                gmemo[(int) (guess.charAt(i) - '0')]++;
////            }
////        }
////        for (int i = 0; i < smemo.length; i++) {
////            cow += Math.min(smemo[i], gmemo[i]);
////        }
////        return bull + "A" + cow + "B";
////    }
////
////    public static void main(String[] args) {
////        int port = 44;
////        try {
////            Thread t = new Main(port);
////            t.start();
////        } catch (IOException e) {
////            e.printStackTrace();
////        }
////    }
////}
//
